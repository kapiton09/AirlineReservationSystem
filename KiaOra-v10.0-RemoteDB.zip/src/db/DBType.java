package db;
/*
 * 
 *  DBType Enum
 *  Author: Kapil 
 * 
 */

public enum DBType {
	HSQLDB, MYSQL
}
